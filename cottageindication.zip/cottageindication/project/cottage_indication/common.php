<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LOGIN</title>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/custom.css" rel="stylesheet">
<link rel="stylesheet" href="css/materialdesignicons.min.css">
</head>
<body style="background: url('images/pic1.jpg') no-repeat; background-size: cover;">
<div class="login-form">
   
        <img src="images/logo1.png" alt="..." class="img-rounded login-pic">
          
         <h2 class="text-center"> COTTAGE INDICATION </h2>       
        <div class="form-group">
          <a href="add_remainder.php">  <button type="submit" class="btn btn-primary login-btn btn-block" >ADD REMINDER</button> </a>
        </div>
        <div class="form-group">
            <a href="get.php"><button type="submit" class="btn btn-primary login-btn btn-block" >GET REMINDER</button> </a>
        </div>
        
		
        
    

</div>

 <script src="js/jquery-3.2.1.min.js"></script>
 <script src="js/bootstrap.min.js"></script>
</body>
</html>     